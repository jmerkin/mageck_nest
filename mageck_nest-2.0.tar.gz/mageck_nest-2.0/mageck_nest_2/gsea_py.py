import os
import gseapy
import operator
import pandas as pd

def positive_controls_genes_import():
    temp=[]
    os.chdir("/Users/chen-haochen/Documents/Data_storage/CRISPR/collaboration/EZH2/")
    file=open("final_bowtie_final_19bp_sgRNA_hg38_hg38_refseq_CDS_hg38_19bp_sgRNA_complete_score_mut_filter_selection_0.txt")
    file.readline()
    for line in file:
        elements=line.strip().split("\t")
        if elements[24]=="positive_control":
            temp.append(elements[3])
    print list(set(temp))
    return list(set(temp))

def gene_set_file_preparation(target_path,gene_list):
    positive_control_genes_temp=positive_controls_genes_import()
    positive_control_genes=[i for i in positive_control_genes_temp if i in gene_list]
    os.chdir(target_path)
    geneset_file=open("Agilent_6000_positive_controls.gmt",'wt')
    insert=["Agilent_6000","positive_control"]+positive_control_genes
    geneset_file.write("%s\n" %"\t".join(insert))

def rnk_file_preparation(target_path,mageck_nest_file,to_be_rank_column_name,reverse=False):
    os.chdir(target_path)
    gene_list=[]
    temp_list=[]
    file=open(mageck_nest_file)
    column_index=file.readline().strip().split("\t").index(to_be_rank_column_name)
    for line in file:
        elements=line.strip().split("\t")
        if abs(float(elements[column_index]))<5:
            temp_list.append([elements[0],float(elements[column_index])])
            gene_list.append(elements[0])
    temp_list.sort(key=operator.itemgetter(1),reverse=reverse)
    output=open("rank_%s.rnk" %mageck_nest_file[:mageck_nest_file.index(".txt")],'wt')
    for i in temp_list:
        try:
            float(i[1])
            output.write("%s\n" %"\t".join([str(k) for k in i]))
        except ValueError:
            print("wrong")
    return gene_list

def main():
    target_path="/Users/chen-haochen/Documents/Data_storage/CRISPR/MAGECK/Tim_science_6_outliers_test_v2/mageck_bayes_tim_science_KBM7_intial_all_guides_control/"
    mageck_nest_file="mageck_bayes_tim_science_KBM7_intial_all_guides_control_PPI_major_outliers_removal_major.gene_summary.txt"
    short_name=mageck_nest_file[:mageck_nest_file.index(".txt")]

    os.chdir(target_path)

    to_be_rank_column_name=["beta_1|beta"]
    for column in to_be_rank_column_name:
        gene_list=rnk_file_preparation(target_path,mageck_nest_file,column,reverse=False)
        gene_set_file_preparation(target_path,gene_list)
        ranked_file="rank_%s.rnk" %short_name
        gseapy.prerank(rnk="/%s/%s" %(target_path,ranked_file), gene_sets="Agilent_6000_positive_controls.gmt", outdir="%s_positive_control" %(short_name))
        #gseapy.prerank(rnk="/%s/%s" %(target_path,ranked_file), gene_sets='KEGG_2016', outdir="%s_KEGG2016" %(short_name))

positive_controls_genes_import()
#main()
