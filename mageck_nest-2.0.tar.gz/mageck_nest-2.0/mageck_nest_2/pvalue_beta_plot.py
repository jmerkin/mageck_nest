import os
import scipy.stats as stats
import matplotlib.pyplot as pylab
import numpy as np
from scipy.stats import norm
import statsmodels.api as sm
import logging
from collections import defaultdict
import gseapy
import operator
import pandas as pd
import glob

def gene_set_file_preparation(gene_list,output_name):
    positive_control_genes_temp=['RANGRF', 'RPN2', 'U2AF2', 'FTSJ3', 'CHMP2A', 'EIF3H',
    'EIF3I', 'RAN', 'EIF3A', 'EIF3B', 'EIF3C', 'EIF3D', 'EIF3F', 'EIF3G', 'NAPA',
    'RPLP2', 'LUC7L3', 'WDR5', 'NUP98', 'NUP93', 'RPL14', 'USP39', 'RINT1', 'RPL10',
    'RPL11', 'RPL12', 'RPL13', 'RPL18', 'KRAS', 'SHFM1', 'SNRPD2', 'SNRPD1', 'PHB',
    'ARCN1', 'COPB1', 'RPL37A', 'COPS2', 'RPL7', 'RPL4', 'RPL5', 'CLTC', 'EIF5B',
    'XRCC6', 'COPZ1', 'CCT8', 'RPL7A', 'RUVBL2', 'U2AF1', 'CCT3', 'DDX51', 'CCT7',
    'CCT4', 'EFTUD2', 'SF3A1', 'SF3A2', 'RPS3A', 'INTS9', 'ETF1', 'NACA', 'PRKAB2',
    'SDAD1', 'SNRNP200', 'CDK11B', 'POLR2D', 'SFPQ', 'POLR2A', 'POLR2I', 'POLR2K',
    'TAF2', 'PSMD11', 'TUBB', 'SUPT5H', 'PHF5A', 'PRPF31', 'EIF4A3', 'GRPEL2', 'YY1',
    'RFC4', 'RPLP0', 'RPL18A', 'RPL35A', 'RPS15A', 'PELP1', 'RPS7', 'RPS9', 'BRIX1',
    'RPL13A', 'RPL6', 'HNRNPU', 'PSMA2', 'PSMA3', 'PSMA1', 'RBM17', 'HNRNPM', 'SF3B4',
    'HNRNPC', 'RPS26', 'RPS24', 'RPS27A', 'SNRNP70', 'RPSA', 'RPL10A', 'TUBGCP3', 'PSMB3',
    'PSMB2', 'RPS13', 'KARS', 'RPS11', 'RPS17', 'RPS14', 'SF3B5', 'RPL32', 'PSMD7', 'PSMD6',
    'PSMD1', 'SF3B3', 'RRM1', 'RPL31', 'EIF2S2', 'RPTOR', 'AQR', 'PRPF19', 'PRPF18', 'RPL27',
    'RPL26', 'CDK17', 'RPL23', 'PSMC4', 'ICK', 'CDC5L', 'HEATR1', 'LSM4', 'LSM6',
    'KPNB1', 'LSM3', 'VCP', 'DYNC1H1', 'PAPOLA', 'SNRPE', 'RPL36', 'RPL37', 'RPL34',
    'RPA1', 'RPA2', 'ACTR1A', 'TUBA1B', 'EEF2']
    geneset_file=open("%s_gsea.gmt" %output_name,'wt')
    positive_control_genes=[i.upper() for i in gene_list if i in positive_control_genes_temp]
    insert=["%s_gsea" %output_name,"%s_gsea" %output_name]+positive_control_genes
    geneset_file.write("%s\n" %"\t".join(insert))

def rnk_file_preparation(file_name,to_be_rank_column_name,output_name,reverse=False):
    gene_list=[]
    temp_list=[]
    file=open(file_name)
    column_index=file.readline().strip().split("\t").index(to_be_rank_column_name)
    for line in file:
        elements=line.strip().split("\t")
        if abs(float(elements[column_index]))<5:
            temp_list.append([elements[0],float(elements[column_index])])
            gene_list.append(elements[0])
    temp_list.sort(key=operator.itemgetter(1),reverse=reverse)
    output=open("%s.rnk" %output_name,'wt')
    for i in temp_list:
        try:
            float(i[1])
            output.write("%s\n" %"\t".join([str(k) for k in i]))
        except ValueError:
            print("wrong")
    return gene_list

def gsea_main(target_path,file_name):
    data=open(file_name,'rb')
    title=data.readline().decode().strip().split("\t")
    to_be_rank_column_name=[i for i in title if "|beta" in i]

    for column_name in to_be_rank_column_name:
        short_column_name=column_name[:column_name.index("|")]
        output_name="%s_%s" %(file_name[:file_name.index(".txt")],short_column_name)
        gene_list=rnk_file_preparation(file_name,column_name,output_name,reverse=False)
        gene_set_file_preparation(gene_list,output_name)

        ranked_file="%s.rnk" %output_name
        gseapy.prerank(rnk="%s" %(ranked_file), gene_sets="%s_gsea.gmt" %output_name,outdir=target_path)
    for file in glob.glob("*.gmt"):
        os.remove(file)
    for file in glob.glob("*.rnk"):
        os.remove(file)

def plot(target_path,file_name,negative_control=None,wald_only=False):
    data=open(file_name,'rb')
    short_file_name=file_name[:file_name.index(".gene_summary.txt")]
    title=data.readline().decode().strip().split("\t")
    beta_value_columns=[title.index(i) for i in title if "|beta" in i]
    beta_value_names=[i[:i.index("|")] for i in [title[k] for k in beta_value_columns]]
    pvalue_columns=[title.index(i) for i in title if "|wald-p-value" in i]
    pvalue_names=[i[:i.index("|")] for i in [title[k] for k in beta_value_columns]]

    wald_p_value_list={i:[] for i in pvalue_names}
    beta_value_list={i:[] for i in beta_value_names}

    for line in data:
        elements=line.decode().strip().split("\t")
        if elements[0] not in negative_control:
            for i in range(len(pvalue_names)):
                beta_value_list[beta_value_names[i]].append(float(elements[beta_value_columns[i]]))
                wald_p_value_list[pvalue_names[i]].append(float(elements[pvalue_columns[i]]))

    for key,values in beta_value_list.items():
        beta_value_list[key]=[x for x in values if str(x) != 'nan' and abs(x)<5]
        if len(beta_value_list[key])>3000:
            pylab.hist(beta_value_list[key],bins=1000)
            pylab.savefig("Hist of %s beta value %s .pdf" %(key,short_file_name))
            pylab.close()
        else:
            pylab.hist(beta_value_list[key],bins=100)
            pylab.savefig("Hist of %s beta value %s .pdf" %(key,short_file_name))
            pylab.close()
        os.rename("Hist of %s beta value %s .pdf" %(key,short_file_name), "/%s/Hist of %s beta value %s .pdf" %(target_path,key,short_file_name))

    for key,values in wald_p_value_list.items():
        wald_p_value_list[key]=[x for x in values if str(x) != 'nan']
        fig=sm.qqplot(np.array(wald_p_value_list[key]),stats.uniform,fit=True, line='45')
        pylab.xlim(0,1)
        pylab.ylim(0,1)
        pylab.savefig("QQplot of %s wald_p value %s.pdf" %(key,short_file_name))
        pylab.close()
        os.rename("QQplot of %s wald_p value %s.pdf" %(key,short_file_name),"/%s/QQplot of %s wald_p value %s.pdf" %(target_path,key,short_file_name))
