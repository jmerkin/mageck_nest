import os
import scipy.stats as stats
import matplotlib.pyplot as pylab
import numpy as np
from scipy.stats import norm
import statsmodels.api as sm
import logging
from collections import defaultdict

def plot(file_name,negative_control=None,wald_only=False):
    data=open(file_name,'rb')
    short_file_name=file_name[:file_name.index(".gene_summary.txt")]
    title=data.readline().decode().strip().split("\t")
    beta_value_columns=[title.index(i) for i in title if "|beta" in i]
    beta_value_names=[i[:i.index("|")] for i in [title[k] for k in beta_value_columns]]
    pvalue_columns=[title.index(i) for i in title if "|wald-p-value" in i]
    pvalue_names=[i[:i.index("|")] for i in [title[k] for k in beta_value_columns]]

    wald_p_value_list={i:[] for i in pvalue_names}
    beta_value_list={i:[] for i in beta_value_names}

    for line in data:
        elements=line.decode().strip().split("\t")
        if elements[0] not in negative_control:
            for i in range(len(pvalue_names)):
                beta_value_list[beta_value_names[i]].append(float(elements[beta_value_columns[i]]))
                wald_p_value_list[pvalue_names[i]].append(float(elements[pvalue_columns[i]]))

    for key,values in beta_value_list.items():
        beta_value_list[key]=[x for x in values if str(x) != 'nan' and abs(x)<5]
        pylab.hist(beta_value_list[key],bins=1000)
        pylab.savefig("Hist of %s beta value %s .pdf" %(key,short_file_name))
        pylab.close()

    for key,values in wald_p_value_list.items():
        wald_p_value_list[key]=[x for x in values if str(x) != 'nan']
        fig=sm.qqplot(np.array(wald_p_value_list[key]),stats.uniform,fit=True, line='45')
        pylab.xlim(0,1)
        pylab.ylim(0,1)
        pylab.savefig("QQplot of %s wald_p value %s.pdf" %(key,short_file_name))
        pylab.close()
