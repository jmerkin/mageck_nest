import os
from collections import Counter,defaultdict
import numpy as np
import operator
from scipy.stats import norm

def removal_suggestion(self):
    reverse_size_factor=[float(1)/i for i in self.size_f]
    #print reverse_size_factor

    transform_design_list=[tuple(i) for i in self.design_matrix.tolist()]
    categories=Counter(transform_design_list).keys()
    indexes=[]
    for category in categories:
        indexes.append([i for i in range(len(transform_design_list)) if transform_design_list[i]==category])
    include_samples_categories=[[self.include_samples[j] for j in i] for i in indexes]
    reverse_size_factor_categories=[[reverse_size_factor[j] for j in i] for i in indexes]
    #print reverse_size_factor_categories

    all_combinations=[]
    for i in range(len(include_samples_categories)):
        for j in range(len(include_samples_categories)):
            if j>i:
                all_combinations.append((i,j))

    file=open(self.count_table)
    if (self.count_table).upper().endswith('.CSV'):
        field=file.readline().strip().split(",")
    else:
        field=file.readline().strip().split('\t')
    field_index=[[field.index(i) for i in j] for j in include_samples_categories]

    fc_record=defaultdict(list)
    for line in file:
        if (self.count_table).upper().endswith('.CSV'):
            elements=file.readline().strip().split(",")
        else:
            elements=line.strip().split('\t')
        temp=[]
        for combination in all_combinations:
            values_1=np.multiply([float(elements[i])+1 for i in field_index[combination[0]]],reverse_size_factor_categories[combination[0]])
            values_2=np.multiply([float(elements[i])+1 for i in field_index[combination[1]]],reverse_size_factor_categories[combination[1]])
            fc_record[combination].append([elements[0].upper(),np.log(float(np.mean(values_1))/np.mean(values_2))])

    suggested_remove_sgRNA=[]
    for combination,fc in fc_record.items():
        #fc.sort(key=operator.itemgetter(1))

        fc_value=[i[1] for i in fc]
        fc_value_median=np.median(fc_value)
        abs_fc=[abs(i-fc_value_median) for i in fc_value]
        abs_fc.sort()
        #var_fc=float(np.percentile(abs_fc,95))/norm.ppf(0.975)
        var_fc=float(np.percentile(abs_fc,68))/norm.ppf(0.84)
        suggested_remove_sgRNA+=[i[0] for i in fc if abs(i[1]/var_fc)>2]
        '''
        suggested_remove_sgRNA+=[i[0] for i in fc[:int((len(fc)*0.05))]]
        suggested_remove_sgRNA+=[i[0] for i in fc[int(len(fc)*0.95):]]
        '''
    return suggested_remove_sgRNA
