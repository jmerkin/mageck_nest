import os
import pickle
import numpy as np
import matplotlib.pyplot as pylab
import operator
import glob
from collections import Counter,defaultdict
from scipy.stats import norm
import logging
from sklearn import linear_model

def bayes_selection_constnat_optimization(self):

    eff_likelihood_record=[]
    outliers_likelihood_record=[]
    for (tgid,tginst) in self.allgenedict.items():
        if tgid not in self.negative_control:
            likelihood= np.matrix(tginst.loglikelihood.reshape(tginst.nb_count.shape[0],tginst.nb_count.shape[1]))
            likelihood_mean= np.matrix(np.mean(likelihood,axis=0))
            likelihood_list=likelihood_mean.tolist()[0]
            eff_list=tginst.eff_estimate
            for i in range(len(eff_list)):
                if eff_list[i]==0:
                    outliers_likelihood_record.append(likelihood_list[i])
                else:
                    eff_likelihood_record.append(likelihood_list[i])
    outliers_likelihood_record.sort()
    #logging.info(outliers_likelihood_record)
    #logging.info(sorted_outliers_likelihood_record)
    self.selection_constant=outliers_likelihood_record[int(len(outliers_likelihood_record)*0.9)]
    #logging.info(len([i for i in eff_likelihood_record if i <self.selection_constant]))

def bayes_selection(tginst,log_list,selection_constant):
    tginst.eff_estimate=[1]*len(tginst.sgrnaid)
    likelihood= np.matrix(tginst.loglikelihood.reshape(tginst.nb_count.shape[0],tginst.nb_count.shape[1]))
    likelihood_mean= np.matrix(np.mean(likelihood,axis=0))
    likelihood_list=likelihood_mean.tolist()[0]
    for i in range(len(likelihood_list)):
        if likelihood_list[i]<selection_constant:
            tginst.eff_estimate[i]=0
