import os
import numpy as np

def deviation(allgenedict):
    mu_estimate=[]
    k_estimate=[]
    ratio_list=[]

    for (gid,gsk) in allgenedict.iteritems():
        nsg=len(gsk.nb_count[0])
        nsample=len(gsk.nb_count)
        k=[x[0] for x in gsk.sgrna_kvalue.tolist()]
        mu=[x[0] for x in gsk.mu_estimate.tolist()]

        k_estimate+=k
        mu_estimate+=mu

    if len(k_estimate)==len(mu_estimate):
        for i in range(len(k_estimate)):
            ratio_list.append(abs(mu_estimate[i]-k_estimate[i])/(k_estimate[i]))

    ratio_list.sort()
    return [str(np.mean(ratio_list[int(len(ratio_list)*0.1):int(len(ratio_list)*0.9)])),str(np.median(ratio_list))]

def deviation_single_gene(gsk):
    k=[x[0] for x in gsk.sgrna_kvalue.tolist()]
    mu=[x[0] for x in gsk.mu_estimate.tolist()]
    #print(k)
    #print(mu)
